package com.app.admin.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.app.admin.entity.CreateAccountEntity;

public interface CreateAccountRepository extends JpaRepository<CreateAccountEntity, Serializable> {
	
	@Query(value = "select  ACCOUNT_ID from Account_Master where ACCOUNT_ID= :email;", nativeQuery = true)
	public Boolean checkEmail(String email);

	public CreateAccountEntity findByEmailAndPassword(String userEmail,String userPassword);

	public CreateAccountEntity findByEmail(String email);
	
	
}
