package com.app.admin.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.app.admin.entity.CreateAccountEntity;
import com.app.admin.model.CreateAccount;
import com.app.login.model.UserLoginDetails;

@Service
public interface CreateAccountService {

	boolean saveAccount(CreateAccount ca);

	boolean updateAccount(CreateAccount ca);

	public CreateAccountEntity getAccountByUserEmailAndUserPassword(String email, String tempPwd);

	boolean updateAccount(CreateAccountEntity entity);

	public List<CreateAccountEntity> getAllAccounts();

	boolean deleteAccount(Integer accountId);

	boolean activateAccount(Integer accountId);

	public CreateAccount getAccountById(Integer accountId);

	public String findByEmail(String email);

	public CreateAccountEntity checkCredintials(UserLoginDetails details);

	CreateAccountEntity fetchRecordByEmail(String email);
	
	

}
