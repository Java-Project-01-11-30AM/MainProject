package com.app.login.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.app.admin.entity.CreateAccountEntity;
import com.app.admin.service.CreateAccountService;
import com.app.constants.AppConstants;
import com.app.login.model.UserLoginDetails;

@Controller
public class loginFormController {
	@Autowired
	private CreateAccountService userService;
/**
 * 	This method for launching login page
 * @param model
 * @return
 */
	
	@RequestMapping("/")
	public String getLoginForm(Model model) {
		UserLoginDetails loginDetails = new UserLoginDetails();
		model.addAttribute("loginBean", loginDetails);
		return AppConstants.LOGINSTR;
	}
	
	/**
	 *  This methodn for handling login submition
	 * @param details
	 * @param model
	 * @return
	 */
	@RequestMapping("/userLogin")
	public String handleloginBtn(@ModelAttribute("loginBean") UserLoginDetails details, Model model) {
		CreateAccountEntity entity = userService.checkCredintials(details);
		if (entity != null) {
			if ("locked".equalsIgnoreCase(entity.getLockStatus())) {
				model.addAttribute("errMsg", "Account is Locked");
			} else {
					return "redirect:/dashBoared";
			}
		} else {
			model.addAttribute("errMsg", "Enter valid credintials");
		}

		return AppConstants.LOGINSTR;
	}
	 
	/**
	 *  This method for redireting to dashBoard page
	 * @return
	 */
	
	@RequestMapping("/dashBoared")
	public String showdashBoared() {
		return AppConstants.DASHSTR;
				
	}
	/*
	 * @GetMapping("/validateEmail")
	 * 
	 * @ResponseBody public String validateEmail(HttpServletRequest req) { String
	 * email = req.getParameter("email"); String emailStatus =
	 * userService.findByEmail(email); return emailStatus; }
	 */
}
