package com.app.login.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.app.admin.entity.CreateAccountEntity;
import com.app.admin.service.CreateAccountService;
import com.app.constants.AppConstants;
import com.app.login.model.UserForgetPasswordDetails;
import com.app.utils.EmailUtils;

@Controller
public class UserFogetPwdDetailsController {
	
	private static Logger logger= LoggerFactory.getLogger(UserFogetPwdDetailsController.class);
	@Autowired
	private CreateAccountService userService;

	@Autowired
	private EmailUtils smsUtils;

	/**
	 * This method for launching forget password page
	 * 
	 * @param model
	 * @return
	 */

	@RequestMapping("/showForgetPwd")
	public String showForm(Model model) {
		logger.debug("**************showFormMethod Execution started**********");
		UserForgetPasswordDetails details = new UserForgetPasswordDetails();
		model.addAttribute("fPwd", details);
		logger.debug("**************showFormMethod Execution ended**********");
		return AppConstants.FPWDSTR;
	}

	/**
	 * This methos for handle forget password submitions
	 * 
	 * @param details
	 * @param model
	 * @return
	 */

	@RequestMapping(value = "/forget", method = { RequestMethod.GET, RequestMethod.POST })
	public String handleForgetPwdBtn(@ModelAttribute("fPwd") UserForgetPasswordDetails details, Model model) {
		logger.debug("**************handleForgetPwdBtn Execution started**********");
		CreateAccountEntity fetchRecordByUserEmail = userService.fetchRecordByEmail(details.getEmail());
		if (fetchRecordByUserEmail != null) {
			String accStatus = fetchRecordByUserEmail.getLockStatus();
			//String userPazzword = fetchRecordByUserEmail.getUserPazzword();
			if (accStatus.equalsIgnoreCase("LOCKED")) {
				model.addAttribute("succMsg", "Check your email to get password");
				logger.debug("**************Check your email to get password msg sent successfully**********");
				return AppConstants.FPWDSTR;
			} else if (accStatus.equalsIgnoreCase("UN-LOCKED")) {
				 String userPazzword=fetchRecordByUserEmail.getPassword();
				smsUtils.sendUserSmsOtp(userPazzword);
				model.addAttribute("resetMsg", "password sent to ********680");
				logger.debug("**************restpassword form opened successfully**********");
				return "resetPasswordForm";

			}

		}
		model.addAttribute("failMsg", "Incorrect Email");
		logger.debug("**************Incorrect Email msg sent succesfully**********");
		return AppConstants.FPWDSTR;
	}
}
