package com.app.ar.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.ar.entity.CreateApplicationRegistrationEntity;

public interface CreateApplicationRegistrationRepository extends JpaRepository<CreateApplicationRegistrationEntity, Serializable> {
	
	//@Query(value = "select  USER_ID from Application_Registration where USER_ID= :ssn;", nativeQuery = true)
	//public Boolean checkSsn(String ssn);

	//public CreateAccountEntity findByEmailAndPassword(String userEmail,String userPassword);

	/* public CreateApplicationRegistrationEntity findById(); */
	
	
}
