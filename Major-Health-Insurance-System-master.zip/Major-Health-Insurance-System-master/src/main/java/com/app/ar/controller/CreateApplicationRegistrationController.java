package com.app.ar.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.ar.model.CreateApplicationRegistration;
import com.app.ar.service.CreateApplicationRegistrationService;

@Controller
public class CreateApplicationRegistrationController {
	@Autowired
	private CreateApplicationRegistrationService ARservice;
	

	@GetMapping("/loadApplicationRegistrationForm")
	public String loadCreateAccountform(Model model) {
		CreateApplicationRegistration car = new CreateApplicationRegistration();
		model.addAttribute("account", car);
		return "CreateApplicationRegistration";
	}

	
	  @PostMapping("/generateId")
	  public String  handleCreateAccountform(@ModelAttribute("account") CreateApplicationRegistration car,
	  RedirectAttributes attributes) {
		  
		  Integer accountId = ARservice.saveCreateApplicationRegistration(car).getAccountId();
		  
		 
		if(accountId!=null) {
			  attributes.addFlashAttribute("msg", "Your registration is almost complete with RegID" + accountId);
			  return "redirect:/loadApplicationRegistrationForm";
		  }
		  attributes.addFlashAttribute("errMsg", "OOps Failed to create account.... as ssn is not valid!");
		  return "redirectL/loadApplicationRegistrationForm";
	  }
	 	
	 
	/*
	 * @GetMapping("/viewAccount") public String viewAccountBtn(Model model) {
	 * List<CreateAccountEntity> allAccounts = service.getAllAccounts();
	 * model.addAttribute("accounts", allAccounts); return "ViewAccount"; }
	 * 
	 * @GetMapping("/editAccount") public String editAccount(@RequestParam("aid")
	 * Integer accountId, Model model) { CreateAccount ca =
	 * service.getAccountById(accountId); model.addAttribute("account", ca); return
	 * "CreateAccount"; }
	 * 
	 * @GetMapping("/deleteAccount") public String
	 * deleteAccount(@RequestParam("aid") Integer accountId, RedirectAttributes
	 * attributes) { boolean isDeleted = service.deleteAccount(accountId); if
	 * (isDeleted) { attributes.addFlashAttribute("DeleteMsg",
	 * "Account Deleted Successfully!!.."); return "redirect:/viewAccount"; } return
	 * null; }
	 * 
	 * @GetMapping("/activateAccount") public String
	 * activateAccount(@RequestParam("aid") Integer accountId, RedirectAttributes
	 * attributes) { boolean isActive = service.activateAccount(accountId); if
	 * (isActive) { attributes.addFlashAttribute("ActivateMsg",
	 * "Account Activated Successfully!!.."); return "redirect:/viewAccount"; }
	 * return null; }
	 */
	/*
	 * @GetMapping("/validateEmail")
	 * 
	 * @ResponseBody public String validateEmail(HttpServletRequest req) { String
	 * email = req.getParameter("email"); String emailStatus =
	 * service.findByEmail(email); return emailStatus; }
	 */
}

