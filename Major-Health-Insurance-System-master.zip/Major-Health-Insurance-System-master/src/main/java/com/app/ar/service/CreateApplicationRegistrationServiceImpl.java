package com.app.ar.service;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.app.admin.entity.CreateAccountEntity;
import com.app.ar.entity.CreateApplicationRegistrationEntity;
import com.app.ar.model.CreateApplicationRegistration;
import com.app.ar.repository.CreateApplicationRegistrationRepository;
import com.app.utils.EmailUtils;
import com.app.utils.PwdUtils;

@Service
public class CreateApplicationRegistrationServiceImpl implements CreateApplicationRegistrationService {

	@Autowired
	private CreateApplicationRegistrationRepository ARrepository;
	
	  @Autowired private EmailUtils utils;
	 
	  @Override
		public CreateApplicationRegistration saveCreateApplicationRegistration(CreateApplicationRegistration car) {
		  
		  CreateApplicationRegistrationEntity entity= new CreateApplicationRegistrationEntity();
		  BeanUtils.copyProperties(car, entity);
		   String ssn = entity.getSsn().toString();
		   
		   boolean isValid = checkSsnValidation(ssn);
		   
		   if(isValid) {
			   entity.setActiveSwitch("Active");
			   entity.setLockStatus("LOCKED");
			   entity.setFirstName(entity.getFirstName() + "" +entity.getLastName());
			   entity.setPassword(PwdUtils.randomAlphaNumeric(6));
			   
			   CreateApplicationRegistrationEntity appRegEntity=ARrepository.save(entity);
			   BeanUtils.copyProperties(appRegEntity, car);
			   
			   return car;
		   }
		   
		   return null;
	  }
	
    @Override
	public boolean checkSsnValidation(String ssn) {
		
    	String restUrl = "http://localhost:6062//validateSsn/{ssn}";
    	WebClient webClient = WebClient.create();
    	String respMsg = webClient.get().uri(restUrl,ssn).retrieve().bodyToMono(String.class).block();
    	if("valid-ssn".equalsIgnoreCase(respMsg)) {
    		return true;
    	}
		return false;
	}


	/*
	 * @Override public String findBySsn(String ssn) { // TODO Auto-generated method
	 * stub return null; }
	 * 
	 * @Override public CreateAccountEntity fetchRecordBySsn(String ssn) { // TODO
	 * Auto-generated method stub return null; }
	 */

	/*
	 * @Override public CreateAccount getAccountById(Integer accountId) {
	 * CreateAccountEntity entity = ARrepository.findById(accountId).get(); if
	 * (entity != null) { CreateAccount ca = new CreateAccount();
	 * BeanUtils.copyProperties(entity, ca); return ca; } return null; }
	 * 
	 * @Override public String findByEmail(String email) { CreateAccountEntity
	 * entity=ARrepository.findByEmail(email); if(null!=entity) { return
	 * "Duplicate"; } return "Unique"; }
	 * 
	 * 
	 * 
	
	 */

}
