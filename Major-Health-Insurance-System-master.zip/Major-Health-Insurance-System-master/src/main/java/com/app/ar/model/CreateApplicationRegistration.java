package com.app.ar.model;

import lombok.Data;

@Data
public class CreateApplicationRegistration {

	private Integer accountId;
	private String firstName;
	private String lastName;
	private String dob;
	private String email;
	 private String phoneNo;
	private String gender;
	private String ssn;

	public Integer getAccountId() {
		return accountId;
	}
	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}
}
