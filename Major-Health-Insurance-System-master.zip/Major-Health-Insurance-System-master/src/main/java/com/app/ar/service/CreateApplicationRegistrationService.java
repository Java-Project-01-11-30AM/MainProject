package com.app.ar.service;

import org.springframework.stereotype.Service;

import com.app.ar.model.CreateApplicationRegistration;

@Service
public interface CreateApplicationRegistrationService {

	

	/*
	 * public String findBySsn(String ssn);
	 * 
	 * 
	 * 
	 * CreateAccountEntity fetchRecordBySsn(String ssn);
	 */



	public CreateApplicationRegistration saveCreateApplicationRegistration(CreateApplicationRegistration car);



	 boolean checkSsnValidation(String ssn);
	
	

}
