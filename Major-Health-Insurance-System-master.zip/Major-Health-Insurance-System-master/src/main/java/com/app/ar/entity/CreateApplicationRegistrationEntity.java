package com.app.ar.entity;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;

import lombok.Data;

@Data
@Entity
@Table(name = "Application_Registration")
public class CreateApplicationRegistrationEntity {

	@Id
	@GeneratedValue
	@Column(name = "ACCOUNT_ID")
	private Integer accountId;

	@Column(name = "FIRST_NAME")
	private String firstName;

	@Column(name = "LAST_NAME")
	private String lastName;
	
	@Column(name = "DOB")
	private String dob;

	@Column(name = "EMAIL")
	private String email;

	@Column(name = "GENDER")
	private String gender;

	@Column(name = "SSN")
	private String ssn;

	
	  // Extra column need to maintain
	  
	  @Column(name = "PHONE_NO")
	  private String phoneNo;
	  
	  @Column(name = "LOCK_STATUS")
	  private String lockStatus;
	  
	  @Column(name = "DELETE_SW")
	  private String deletedSwitch;
	  
	  @Column(name = "PASSWORD") 
	  private String password;
	 

	@CreationTimestamp
	@Temporal(TemporalType.DATE)
	@Column(name = "CREATE_DATE", updatable = false)
	private Date createDate;

	@CreationTimestamp
	@Temporal(TemporalType.DATE)
	@Column(name = "UPDATE_DATE", insertable = false)
	private Date updateDate;
	
	public Integer getAccountId() {
		return accountId;
	}
	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}
	public void setActiveSwitch(String string) {
		// TODO Auto-generated method stub
		
	}

}
